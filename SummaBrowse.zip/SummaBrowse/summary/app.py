import os
# Set PyDev debugger timeout to a higher value
os.environ['PYDEVD_WARN_SLOW_RESOLVE_TIMEOUT'] = '2.0'

from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename
from text_extraction_and_summarization import TextExtractorAndSummarizer
from process_pdf import PDFProcessor

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'output'
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), UPLOAD_FOLDER)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    # Ensure unique filename if it already exists
    if os.path.exists(file_path):
        base, ext = os.path.splitext(filename)
        counter = 1
        while os.path.exists(file_path):
            filename = f"{base}_{counter}{ext}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            counter += 1

    file.save(file_path)

    try:
        text = None
        summary = None

        if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
            # Process image
            summarizer = TextExtractorAndSummarizer()
            text = summarizer.extract_text_from_image(file_path)
            if text:
                summary = summarizer.generate_summary(text)
        elif filename.lower().endswith('.pdf'):
            # Process PDF
            processor = PDFProcessor()
            text = processor.extract_text_with_ocr(file_path)
            if text:
                summary = processor.summarize_text(text)
        else:
            return jsonify({'error': 'Unsupported file type'}), 400

        # Validate extracted text and summary
        if not text:
            return jsonify({'error': 'Failed to extract text from the file'}), 500
        if not summary:
            return jsonify({'error': 'Failed to generate summary'}), 500

        # Save the extracted text to a file
        extracted_text_file = os.path.join(OUTPUT_FOLDER, "extracted_text.txt")
        with open(extracted_text_file, 'w', encoding='utf-8') as f:
            f.write(text)

        # Save the summary to a file
        summary_file = os.path.join(OUTPUT_FOLDER, "summary.txt")
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write(summary)

        return jsonify({
            'extracted_text': text,
            'summary': summary,
            'download_url': f'/downloadsummary.txt'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    file_path = os.path.join(OUTPUT_FOLDER, filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    else:
        # Log the error for debugging
        print(f"File not found: {file_path}")
        return jsonify({'error': f'File {filename} not found'}), 404

if __name__ == '__main__':
    app.run(debug=True)