document.getElementById("uploadButton").addEventListener("click", async () => {
  const fileInput = document.getElementById("fileInput");
  const status = document.getElementById("status");
  const downloadLink = document.getElementById("downloadLink");

  if (!fileInput.files.length) {
    status.textContent = "Please select a file to upload.";
    return;
  }

  const file = fileInput.files[0];
  const formData = new FormData();
  formData.append("file", file);

  status.textContent = "Uploading and processing file...";

  try {
    const response = await fetch("http://127.0.0.1:5000/process", {
      method: "POST",
      body: formData,
    });

    if (!response.ok) {
      throw new Error("Failed to process the file.");
    }

    const data = await response.json();
    if (data.error) {
      throw new Error(data.error);
    }

    status.textContent = "File processed successfully!";
    downloadLink.href = `http://127.0.0.1:5000${data.download_url}`;
    downloadLink.style.display = "block";
  } catch (error) {
    status.textContent = `Error: ${error.message}`;
    downloadLink.style.display = "none";
  }
});

// Dark/Light Mode Toggle
const themeToggle = document.getElementById("themeToggle");
const themeLabel = document.getElementById("themeLabel");

themeToggle.addEventListener("change", () => {
  document.body.classList.toggle("dark-mode");
  themeLabel.textContent = document.body.classList.contains("dark-mode")
    ? "Dark Mode"
    : "Light Mode";
});